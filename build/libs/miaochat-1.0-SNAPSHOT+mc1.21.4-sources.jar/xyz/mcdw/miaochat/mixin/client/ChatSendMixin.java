package xyz.mcdw.miaochat.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xyz.mcdw.miaochat.client.AiService;
import xyz.mcdw.miaochat.client.ChatBypass;
import xyz.mcdw.miaochat.client.ChatHistoryCollector;
import xyz.mcdw.miaochat.client.MiaoChatConfig;
import xyz.mcdw.miaochat.client.MiaochatClient;
import xyz.mcdw.miaochat.client.NyanText;
import xyz.mcdw.miaochat.client.TransformResult;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_634;

@Mixin(class_634.class)
public abstract class ChatSendMixin {

    @Inject(method = "sendChatMessage", at = @At("HEAD"), cancellable = true)
    private void miaochat$onSendChatMessage(String content, CallbackInfo ci) {
        // 防止重入导致无限循环
        if (ChatBypass.isBypassing()) return;
        // 命令直接放行
        if (content.startsWith("/")) return;

        switch (MiaochatClient.getMode()) {
            case NORMAL -> {
                String transformed = NyanText.transform(content);
                ci.cancel();
                ChatBypass.setBypassing(true);
                try {
                    ((class_634) (Object) this).method_45729(transformed);
                } finally {
                    ChatBypass.setBypassing(false);
                }
            }
            case AI -> {
                ci.cancel();
                class_634 self = (class_634) (Object) this;
                class_310 client = class_310.method_1551();

                // 在客户端显示提示
                if (client.field_1724 != null) {
                    client.field_1724.method_7353(
                            class_2561.method_43470("正在润色语言喵~").method_27692(class_124.field_1076),
                            true
                    );
                }

                // 异步调用 AI API
                Thread.startVirtualThread(() -> {
                    List<String> context = ChatHistoryCollector.getRecentPlayerMessages(
                            MiaoChatConfig.getContextSize()
                    );
                    TransformResult result = AiService.transform(content, context);
                    // 回到主线程发送消息
                    client.execute(() -> {
                        if (client.field_1724 != null) {
                            // 清除 action bar
                            client.field_1724.method_7353(class_2561.method_43470(""), true);
                        }

                        // debug 模式：输出调试日志到聊天栏
                        if (MiaoChatConfig.isDebug() && !result.debugLogs().isEmpty()) {
                            if (client.field_1724 != null) {
                                client.field_1724.method_7353(
                                        class_2561.method_43470("\u2500\u2500\u2500\u2500 [MiaoChat Debug] \u2500\u2500\u2500\u2500").method_27692(class_124.field_1063),
                                        false
                                );
                                for (String log : result.debugLogs()) {
                                    client.field_1724.method_7353(
                                            class_2561.method_43470(log).method_27692(class_124.field_1080),
                                            false
                                    );
                                }
                                client.field_1724.method_7353(
                                        class_2561.method_43470("\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500").method_27692(class_124.field_1063),
                                        false
                                );
                            }
                        }

                        // 思考模式：输出思考过程到聊天栏
//                        if (MiaoChatConfig.isThinking() && result.reasoningContent() != null && !result.reasoningContent().isEmpty()) {
//                            if (client.player != null) {
//                                client.player.sendMessage(
//                                        Text.literal("\u2550\u2550 [\u601d\u8003\u8fc7\u7a0b] \u2550\u2550").formatted(Formatting.DARK_PURPLE),
//                                        false
//                                );
//                                // 按行输出思考过程
//                                String[] lines = result.reasoningContent().split("\n");
//                                for (String line : lines) {
//                                    if (!line.isBlank()) {
//                                        client.player.sendMessage(
//                                                Text.literal("\u2582 " + line).formatted(Formatting.LIGHT_PURPLE),
//                                                false
//                                        );
//                                    }
//                                }
//                                client.player.sendMessage(
//                                        Text.literal("\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550").formatted(Formatting.DARK_PURPLE),
//                                        false
//                                );
//                            }
//                        }

                        if (result.isSuccess()) {
                            ChatBypass.setBypassing(true);
                            try {
                                self.method_45729(result.content());
                            } finally {
                                ChatBypass.setBypassing(false);
                            }
                        } else {
                            if (client.field_1724 != null) {
                                client.field_1724.method_7353(
                                        class_2561.method_43470("[MiaoChat] " + result.error()).method_27692(class_124.field_1061),
                                        false
                                );
                            }
                        }
                    });
                });
            }
            case NONE -> {
                // 不做任何处理，直接放行
            }
        }
    }
}
